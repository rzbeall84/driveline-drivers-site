# DriveLine Solutions & Compliance

A professional website combining the services of DriveLine Solutions and DriveLine Compliance into one comprehensive platform.

## About

DriveLine Solutions & Compliance brings trust and transparency to the trucking industry, one driver at a time. We provide comprehensive services for drivers, carriers, and industry professionals.

## Services

### For Drivers
- **Job Placement**: Career-focused matching with reputable carriers nationwide
- **Return to Duty Testing**: No employer needed, Step 5 RTD Testing ($150), Step 6 Follow-Up ($165)
- **SAP Friendly Jobs**: Second-chance opportunities for drivers with violations or background issues

### For Carriers
- **Driver File Management**: Ensure FMCSA compliance
- **Driver Recruitment**: Complete screening process with MVRs, background checks, and safety performance history
- **DOT Drug & Alcohol Testing**: Full-service consortium for all mandatory testing types

### Compliance Services
- **SAP Programs**: Specialized programs and regulatory compliance support
- **Step 5 RTD Testing**: $150
- **Step 6 Follow-Up Management**: $165
- **FMCSA Certified C/TPA**: Professional certification and compliance

### Recruiter Program
- **Driver Recruiter Certification**: 45-minute self-paced course
- **Remote Opportunities**: $250-$3,000 per placement with complete schedule freedom
- **Professional Development**: Continuous support and guidance

## Contact Information

- **Phone**: (877) 724-5965
- **Address**: 3900 Crown Rd, Atlanta, GA 30304
- **Business Hours**: Monday-Friday 9:00 AM - 5:00 PM

## Technology Stack

- **Frontend**: React 18 with Vite
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Animations**: Framer Motion
- **Routing**: React Router DOM
- **UI Components**: Radix UI (shadcn/ui)

## Development

### Prerequisites
- Node.js 18+ 
- pnpm (recommended) or npm

### Installation
```bash
# Clone the repository
git clone <repository-url>
cd driveline-combined

# Install dependencies
pnpm install

# Start development server
pnpm run dev
```

### Available Scripts
- `pnpm run dev` - Start development server
- `pnpm run build` - Build for production
- `pnpm run preview` - Preview production build
- `pnpm run lint` - Run ESLint

## Deployment

This project is configured for deployment on Vercel:

1. Connect your GitHub repository to Vercel
2. Vercel will automatically detect the React/Vite configuration
3. Deploy with default settings

### Build Configuration
- Build Command: `pnpm run build`
- Output Directory: `dist`
- Install Command: `pnpm install`

## Features

- **Responsive Design**: Mobile-first approach with full desktop support
- **Modern UI**: Clean, professional design with smooth animations
- **Fast Performance**: Optimized with Vite for quick loading
- **SEO Friendly**: Proper meta tags and semantic HTML
- **Accessibility**: WCAG compliant with proper ARIA labels
- **Professional Branding**: Consistent with DriveLine Solutions brand identity

## Project Structure

```
src/
├── assets/          # Images and static assets
├── components/      # Reusable React components
│   └── ui/         # UI components (shadcn/ui)
├── hooks/          # Custom React hooks
├── lib/            # Utility functions
├── App.jsx         # Main application component
├── App.css         # Global styles
├── index.css       # Tailwind CSS imports
└── main.jsx        # Application entry point
```

## License

© 2025 DriveLine Solutions & Compliance - All Rights Reserved.

## Support

For technical support or business inquiries, please contact us at (877) 724-5965 or visit our website.


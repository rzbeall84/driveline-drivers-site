import React, { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  CheckCircle, 
  Users, 
  Shield, 
  Award,
  Truck,
  FileText,
  UserCheck,
  Building,
  Menu,
  X,
  ArrowRight
} from 'lucide-react'
import './App.css'

// Import images
import drivelineLogo from './assets/driveline_logo.png'
import truckDriverVision from './assets/truck_driver_vision.jpeg'
import professionalMeeting from './assets/professional_meeting.jpeg'
import officeCompliance from './assets/office_compliance.png'
import professionalDriver from './assets/professional_driver.png'
import servicesBanner from './assets/services_banner.jpeg'

// Navigation Component
const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const location = useLocation()

  const navItems = [
    { path: '/', label: 'Home', color: 'bg-blue-600' },
    { path: '/drivers', label: 'For Drivers', color: 'bg-blue-700' },
    { path: '/carriers', label: 'For Carriers', color: 'bg-blue-800' },
    { path: '/compliance', label: 'Compliance Services', color: 'bg-blue-900' },
    { path: '/recruiters', label: 'Recruiter Program', color: 'bg-slate-700' },
    { path: '/about', label: 'About Us', color: 'bg-slate-600' }
  ]

  return (
    <nav className="bg-white/70 backdrop-blur-2xl border-b border-white/30 shadow-xl sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <img src={drivelineLogo} alt="DriveLine Solutions" className="h-12 w-auto" />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex space-x-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-4 py-2 rounded-lg text-white font-medium transition-all duration-200 hover:scale-105 ${
                  location.pathname === item.path ? item.color : 'bg-gray-600 hover:bg-gray-700'
                }`}
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* Contact Info */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center text-gray-700">
              <Phone className="h-4 w-4 mr-2" />
              <span className="font-semibold">(877) 724-5965</span>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 rounded-md text-gray-700 hover:bg-gray-100"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden pb-4"
            >
              <div className="flex flex-col space-y-2">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                    className={`px-4 py-3 rounded-lg text-white font-medium transition-all duration-200 ${
                      location.pathname === item.path ? item.color : 'bg-gray-600 hover:bg-gray-700'
                    }`}
                  >
                    {item.label}
                  </Link>
                ))}
                <div className="flex items-center justify-center py-3 text-gray-700 border-t">
                  <Phone className="h-4 w-4 mr-2" />
                  <span className="font-semibold">(877) 724-5965</span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  )
}

// Hero Section Component
const HeroSection = () => {
  return (
    <div className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 text-white overflow-hidden">
      <div className="absolute inset-0 bg-black opacity-20"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-7xl font-bold mb-6"
          >
            Bringing Great Drivers
            <br />
            <span className="text-blue-300">& Carriers Together</span>
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto"
          >
            Trust and Transparency in the Trucking Industry, one Driver at a time
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
          >
            <div className="flex items-center bg-white/90 backdrop-blur-sm rounded-lg px-6 py-3 shadow-lg">
              <Phone className="h-6 w-6 mr-3 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">(877) 724-5965</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link
              to="/drivers"
              className="bg-blue-700 hover:bg-blue-800 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-200 hover:scale-105 shadow-lg"
            >
              I'm a Driver
            </Link>
            <Link
              to="/carriers"
              className="bg-blue-800 hover:bg-blue-900 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-200 hover:scale-105 shadow-lg"
            >
              I'm a Carrier
            </Link>
            <Link
              to="/compliance"
              className="bg-slate-700 hover:bg-slate-800 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-200 hover:scale-105 shadow-lg"
            >
              Compliance Services
            </Link>
          </motion.div>
        </div>
      </div>
    </div>
  )
}

// Services Overview Component
const ServicesOverview = () => {
  const services = [
    {
      icon: <Users className="h-12 w-12" />,
      title: "Driver Services",
      description: "Job placement, return to duty testing, and second-chance opportunities",
      features: ["Career-focused matching", "SAP violation assistance", "No employer needed testing"],
      color: "blue-700",
      link: "/drivers"
    },
    {
      icon: <Building className="h-12 w-12" />,
      title: "Carrier Services", 
      description: "Comprehensive driver recruitment and compliance management",
      features: ["Driver file management", "DOT testing consortium", "Complete screening process"],
      color: "blue-800",
      link: "/carriers"
    },
    {
      icon: <Shield className="h-12 w-12" />,
      title: "Compliance Services",
      description: "Specialized SAP programs and regulatory compliance support",
      features: ["Step 5 RTD Testing ($150)", "Step 6 Follow-Up ($165)", "FMCSA certified C/TPA"],
      color: "blue-900",
      link: "/compliance"
    },
    {
      icon: <Award className="h-12 w-12" />,
      title: "Recruiter Program",
      description: "Professional certification and remote opportunities",
      features: ["45-minute certification", "$250-$3,000 per placement", "Complete schedule freedom"],
      color: "slate-700",
      link: "/recruiters"
    }
  ]

  const colorClasses = {
    "blue-700": "from-blue-600 to-blue-800",
    "blue-800": "from-blue-700 to-blue-900", 
    "blue-900": "from-blue-800 to-slate-900",
    "slate-700": "from-slate-600 to-slate-800"
  }

  return (
    <div className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive solutions for drivers, carriers, and industry professionals
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative"
            >
              <div className="bg-white/60 backdrop-blur-2xl border border-white/40 rounded-3xl shadow-2xl hover:shadow-3xl p-8 transition-all duration-500 hover:scale-[1.02] hover:bg-white/70 relative overflow-hidden">
                {/* Subtle gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent rounded-3xl pointer-events-none"></div>
                <div className="relative z-10">
                  <div className={`bg-gradient-to-r ${colorClasses[service.color]} p-4 rounded-2xl mb-6 w-fit shadow-lg`}>
                    <div className="text-white">
                      {service.icon}
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-gray-900">{service.title}</h3>
                  <p className="text-gray-600 mb-6">{service.description}</p>
                  <ul className="space-y-3 mb-8">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link
                    to={service.link}
                    className={`inline-flex items-center bg-gradient-to-r ${colorClasses[service.color]} text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl backdrop-blur-sm`}
                  >
                    Learn More
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}

// Why Choose Us Component
const WhyChooseUs = () => {
  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Why DriveLine Solutions is Different</h2>
            <p className="text-lg text-gray-600 mb-8">
              We understand that many drivers have had disappointing experiences with recruiters who prioritize quick placements over finding the right fit. That's why we've built our company on a different foundation.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Trust & Transparency</h3>
                  <p className="text-gray-600">Honest, transparent guidance for every career decision with realistic expectations.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Second-Chance Opportunities</h3>
                  <p className="text-gray-600">Specialized support for drivers with violations or background issues.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Comprehensive Support</h3>
                  <p className="text-gray-600">From return to duty testing to job placement with reputable carriers.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src={professionalMeeting} 
              alt="Professional meeting" 
              className="rounded-lg shadow-lg w-full"
            />
          </div>
        </div>
      </div>
    </div>
  )
}

// Home Page Component
const HomePage = () => {
  return (
    <div>
      <HeroSection />
      <ServicesOverview />
      <WhyChooseUs />
    </div>
  )
}

// Carriers Page Component
const CarriersPage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-blue-700 to-blue-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold mb-6">Carrier Services</h1>
              <p className="text-xl mb-8">
                Comprehensive driver recruitment and compliance management solutions for motor carriers.
              </p>
              <div className="flex items-center bg-white/90 backdrop-blur-sm rounded-lg px-6 py-3 w-fit shadow-lg">
                <Phone className="h-6 w-6 mr-3 text-blue-600" />
                <span className="text-2xl font-bold text-gray-900">(877) 724-5965</span>
              </div>
            </div>
            <div>
              <img 
                src={servicesBanner} 
                alt="Carrier services" 
                className="rounded-lg shadow-lg w-full max-w-md mx-auto"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Complete Carrier Solutions</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From driver recruitment to compliance management, we provide everything carriers need to succeed.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <Building className="h-12 w-12 text-blue-700 mb-4" />
              <h3 className="text-2xl font-bold mb-4">Driver File Management</h3>
              <p className="text-gray-600 mb-4">
                Ensure FMCSA compliance with comprehensive driver file management and documentation.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  FMCSA compliant documentation
                </li>
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Digital file management
                </li>
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Audit preparation support
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-8">
              <Users className="h-12 w-12 text-blue-700 mb-4" />
              <h3 className="text-2xl font-bold mb-4">Driver Recruitment</h3>
              <p className="text-gray-600 mb-4">
                Complete screening process including MVRs, background checks, and safety performance history.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Comprehensive background checks
                </li>
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  MVR and safety history review
                </li>
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Quality driver matching
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-8">
              <Shield className="h-12 w-12 text-blue-700 mb-4" />
              <h3 className="text-2xl font-bold mb-4">DOT Testing Consortium</h3>
              <p className="text-gray-600 mb-4">
                Full-service DOT drug and alcohol testing consortium for all mandatory testing types.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Pre-employment testing
                </li>
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Random testing programs
                </li>
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Post-accident testing
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-16 bg-blue-50 rounded-lg p-8">
            <div className="text-center">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Ready to Partner With Us?</h3>
              <p className="text-lg text-gray-600 mb-8">
                Let us help you build a compliant, efficient driver recruitment and management program.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <div className="flex items-center bg-white rounded-lg px-6 py-3 shadow-md">
                  <Phone className="h-6 w-6 mr-3 text-blue-700" />
                  <span className="text-2xl font-bold text-gray-900">(877) 724-5965</span>
                </div>
                <div className="flex items-center bg-white rounded-lg px-6 py-3 shadow-md">
                  <MapPin className="h-6 w-6 mr-3 text-blue-700" />
                  <span className="font-semibold text-gray-900">Atlanta, GA</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Compliance Services Page Component
const CompliancePage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-blue-800 to-blue-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold mb-6">Compliance Services</h1>
              <p className="text-xl mb-8">
                Specialized SAP programs and regulatory compliance support for the transportation industry.
              </p>
              <div className="flex items-center bg-white/90 backdrop-blur-sm rounded-lg px-6 py-3 w-fit shadow-lg">
                <Phone className="h-6 w-6 mr-3 text-blue-600" />
                <span className="text-2xl font-bold text-gray-900">(877) 724-5965</span>
              </div>
            </div>
            <div>
              <img 
                src={officeCompliance} 
                alt="Compliance office" 
                className="rounded-lg shadow-lg w-full max-w-md mx-auto"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">FMCSA Certified Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional compliance services with transparent pricing and expert guidance.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <FileText className="h-12 w-12 text-blue-600 mr-4" />
                <div>
                  <h3 className="text-2xl font-bold">Step 5 RTD Testing</h3>
                  <p className="text-3xl font-bold text-blue-600">$150</p>
                </div>
              </div>
              <p className="text-gray-600 mb-4">
                Return to Duty testing for drivers who have completed their SAP program and are ready to return to safety-sensitive duties.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  No employer required
                </li>
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  FMCSA certified testing
                </li>
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Professional documentation
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex items-center mb-6">
                <Shield className="h-12 w-12 text-blue-600 mr-4" />
                <div>
                  <h3 className="text-2xl font-bold">Step 6 Follow-Up</h3>
                  <p className="text-3xl font-bold text-blue-600">$165</p>
                </div>
              </div>
              <p className="text-gray-600 mb-4">
                Follow-up testing management to ensure ongoing compliance with FMCSA regulations after return to duty.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Ongoing monitoring
                </li>
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Compliance tracking
                </li>
                <li className="flex items-center text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Professional support
                </li>
              </ul>
            </div>
          </div>

          <div className="bg-blue-50 rounded-lg p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-3xl font-bold text-gray-900 mb-4">FMCSA Certified C/TPA</h3>
                <p className="text-lg text-gray-600 mb-6">
                  As a certified Consortium/Third Party Administrator, we provide comprehensive drug and alcohol testing programs that meet all FMCSA requirements.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <Award className="h-6 w-6 text-blue-600 mr-3" />
                    <span className="font-semibold">FMCSA Certified</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-6 w-6 text-blue-600 mr-3" />
                    <span className="font-semibold">Full Compliance Support</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-6 w-6 text-blue-600 mr-3" />
                    <span className="font-semibold">Professional Service</span>
                  </li>
                </ul>
              </div>
              <div className="text-center">
                <div className="bg-white rounded-lg p-6 shadow-md">
                  <h4 className="text-xl font-bold mb-4">Get Started Today</h4>
                  <div className="flex items-center justify-center mb-4">
                    <Phone className="h-6 w-6 mr-3 text-blue-600" />
                    <span className="text-2xl font-bold">(877) 724-5965</span>
                  </div>
                  <p className="text-gray-600">Professional compliance services you can trust</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Recruiter Program Page Component
const RecruiterPage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold mb-6">Driver Recruiter Program</h1>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Join our professional recruiter network and earn $250-$3,000 per placement with complete schedule freedom.
            </p>
            <div className="flex items-center justify-center bg-white/90 backdrop-blur-sm rounded-lg px-6 py-3 w-fit mx-auto shadow-lg">
              <Phone className="h-6 w-6 mr-3 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">(877) 724-5965</span>
            </div>
          </div>
        </div>
      </div>

      <div className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Why Choose Our Program?</h2>
              <p className="text-lg text-gray-600 mb-8">
                Unlike other recruiting programs, we focus on quality placements and long-term success for both drivers and recruiters.
              </p>
              <div className="space-y-6">
                <div className="flex items-start">
                  <Award className="h-8 w-8 text-slate-700 mr-4 mt-1" />
                  <div>
                    <h3 className="text-xl font-bold mb-2">Professional Certification</h3>
                    <p className="text-gray-600">Complete our 45-minute self-paced certification course and start earning immediately.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Users className="h-8 w-8 text-slate-700 mr-4 mt-1" />
                  <div>
                    <h3 className="text-xl font-bold mb-2">High Earning Potential</h3>
                    <p className="text-gray-600">Earn $250-$3,000 per successful driver placement with our competitive commission structure.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Clock className="h-8 w-8 text-slate-700 mr-4 mt-1" />
                  <div>
                    <h3 className="text-xl font-bold mb-2">Complete Freedom</h3>
                    <p className="text-gray-600">Work on your own schedule with no quotas or pressure - perfect for remote work.</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <img 
                src={professionalMeeting} 
                alt="Professional recruiter meeting" 
                className="rounded-lg shadow-lg w-full"
              />
            </div>
          </div>

          <div className="bg-slate-50 rounded-lg p-8 mb-16">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">How It Works</h3>
              <p className="text-lg text-gray-600">Simple steps to start your recruiting career</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-slate-700 text-white rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mx-auto mb-4">1</div>
                <h4 className="text-xl font-bold mb-2">Get Certified</h4>
                <p className="text-gray-600">Complete our 45-minute online certification course at your own pace.</p>
              </div>
              <div className="text-center">
                <div className="bg-slate-700 text-white rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mx-auto mb-4">2</div>
                <h4 className="text-xl font-bold mb-2">Start Recruiting</h4>
                <p className="text-gray-600">Use our proven system to connect quality drivers with reputable carriers.</p>
              </div>
              <div className="text-center">
                <div className="bg-slate-700 text-white rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mx-auto mb-4">3</div>
                <h4 className="text-xl font-bold mb-2">Earn Commissions</h4>
                <p className="text-gray-600">Get paid $250-$3,000 for each successful driver placement you make.</p>
              </div>
            </div>
          </div>

          <div className="text-center">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Ready to Get Started?</h3>
            <p className="text-lg text-gray-600 mb-8">
              Join our network of successful recruiters and start building your income today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <div className="flex items-center bg-white rounded-lg px-6 py-3 shadow-md">
                <Phone className="h-6 w-6 mr-3 text-slate-700" />
                <span className="text-2xl font-bold text-gray-900">(877) 724-5965</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// About Us Page Component
const AboutPage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-slate-600 to-slate-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold mb-6">About DriveLine Solutions & Compliance</h1>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Bringing trust and transparency to the trucking industry, one driver at a time.
            </p>
          </div>
        </div>
      </div>

      <div className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Mission</h2>
              <p className="text-lg text-gray-600 mb-6">
                We understand that many drivers have had disappointing experiences with recruiters who prioritize quick placements over finding the right fit. That's why we've built our company on a different foundation.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                Our mission is to restore trust and transparency in the trucking industry by providing honest guidance, second-chance opportunities, and comprehensive support for drivers, carriers, and industry professionals.
              </p>
              <div className="space-y-4">
                <div className="flex items-center">
                  <CheckCircle className="h-6 w-6 text-teal-600 mr-3" />
                  <span className="font-semibold">Trust & Transparency in every interaction</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-6 w-6 text-teal-600 mr-3" />
                  <span className="font-semibold">Second-chance opportunities for all drivers</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-6 w-6 text-teal-600 mr-3" />
                  <span className="font-semibold">Comprehensive support throughout the process</span>
                </div>
              </div>
            </div>
            <div>
              <img 
                src={truckDriverVision} 
                alt="Professional truck driver" 
                className="rounded-lg shadow-lg w-full"
              />
            </div>
          </div>

          <div className="bg-teal-50 rounded-lg p-8 mb-16">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Our Values</h3>
              <p className="text-lg text-gray-600">The principles that guide everything we do</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <Shield className="h-16 w-16 text-teal-600 mx-auto mb-4" />
                <h4 className="text-xl font-bold mb-2">Integrity</h4>
                <p className="text-gray-600">Honest, transparent communication in every interaction with realistic expectations.</p>
              </div>
              <div className="text-center">
                <Users className="h-16 w-16 text-teal-600 mx-auto mb-4" />
                <h4 className="text-xl font-bold mb-2">Opportunity</h4>
                <p className="text-gray-600">Creating second-chance opportunities for drivers with violations or background issues.</p>
              </div>
              <div className="text-center">
                <Award className="h-16 w-16 text-teal-600 mx-auto mb-4" />
                <h4 className="text-xl font-bold mb-2">Excellence</h4>
                <p className="text-gray-600">Professional service and comprehensive support throughout every step of the process.</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <img 
                src={professionalMeeting} 
                alt="Professional business meeting" 
                className="rounded-lg shadow-lg w-full"
              />
            </div>
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-6">Why We're Different</h3>
              <p className="text-lg text-gray-600 mb-6">
                Unlike traditional recruiting companies that focus on volume, we prioritize quality matches and long-term success. Our approach ensures that drivers find careers that truly fit their needs and goals.
              </p>
              <div className="space-y-4">
                <div className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-teal-600 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Career-Focused Matching</h4>
                    <p className="text-gray-600">We don't just find jobs - we help build careers that last.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-teal-600 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Comprehensive Support</h4>
                    <p className="text-gray-600">From testing to placement, we're with you every step of the way.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-teal-600 mr-3 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Industry Expertise</h4>
                    <p className="text-gray-600">FMCSA certified with deep knowledge of compliance requirements.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-20 text-center">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Ready to Experience the Difference?</h3>
            <p className="text-lg text-gray-600 mb-8">
              Contact us today to learn how we can help you succeed in the trucking industry.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <div className="flex items-center bg-white rounded-lg px-6 py-3 shadow-md">
                <Phone className="h-6 w-6 mr-3 text-teal-600" />
                <span className="text-2xl font-bold text-gray-900">(877) 724-5965</span>
              </div>
              <div className="flex items-center bg-white rounded-lg px-6 py-3 shadow-md">
                <MapPin className="h-6 w-6 mr-3 text-teal-600" />
                <span className="font-semibold text-gray-900">3900 Crown Rd, Atlanta, GA 30304</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Drivers Page Component
const DriversPage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold mb-6">Driver Services</h1>
              <p className="text-xl mb-8">
                We believe every driver deserves more than just a job – they deserve a career that fits.
              </p>
              <div className="flex items-center bg-white/90 backdrop-blur-sm rounded-lg px-6 py-3 w-fit shadow-lg">
                <Phone className="h-6 w-6 mr-3 text-blue-600" />
                <span className="text-2xl font-bold text-gray-900">(877) 724-5965</span>
              </div>
            </div>
            <div>
              <img 
                src={professionalDriver} 
                alt="Professional driver" 
                className="rounded-lg shadow-lg w-full max-w-md mx-auto"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white/60 backdrop-blur-2xl border border-white/40 rounded-3xl shadow-2xl hover:shadow-3xl p-8 transition-all duration-500 hover:scale-[1.02] hover:bg-white/70 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 to-transparent rounded-3xl pointer-events-none"></div>
              <div className="relative z-10">
                <UserCheck className="h-12 w-12 text-blue-600 mb-4" />
                <h3 className="text-2xl font-bold mb-4">Job Placement</h3>
                <p className="text-gray-600 mb-4">
                  We connect drivers with reputable companies across the U.S., ensuring the best fit for their skills and experience.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Career-focused matching
                  </li>
                  <li className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Nationwide opportunities
                  </li>
                  <li className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Skills alignment
                  </li>
                </ul>
              </div>
            </div>

            <div className="bg-white/60 backdrop-blur-2xl border border-white/40 rounded-3xl shadow-2xl hover:shadow-3xl p-8 transition-all duration-500 hover:scale-[1.02] hover:bg-white/70 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 to-transparent rounded-3xl pointer-events-none"></div>
              <div className="relative z-10">
                <FileText className="h-12 w-12 text-blue-600 mb-4" />
                <h3 className="text-2xl font-bold mb-4">Return to Duty Testing</h3>
                <p className="text-gray-600 mb-4">
                  If you've been sidelined, we assist in Return to Duty Testing, helping you get back on the road.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    No employer needed
                  </li>
                  <li className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Step 5 RTD Testing ($150)
                  </li>
                  <li className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Step 6 Follow-Up ($165)
                  </li>
                </ul>
              </div>
            </div>

            <div className="bg-white/60 backdrop-blur-2xl border border-white/40 rounded-3xl shadow-2xl hover:shadow-3xl p-8 transition-all duration-500 hover:scale-[1.02] hover:bg-white/70 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 to-transparent rounded-3xl pointer-events-none"></div>
              <div className="relative z-10">
                <Shield className="h-12 w-12 text-blue-600 mb-4" />
                <h3 className="text-2xl font-bold mb-4">SAP Friendly Jobs</h3>
                <p className="text-gray-600 mb-4">
                  For drivers with SAP violations or MVR/background issues, we match you with carriers that provide second-chance opportunities.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    SAP violation assistance
                  </li>
                  <li className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Understanding employers
                  </li>
                  <li className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Second-chance opportunities
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Footer Component
const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <img src={drivelineLogo} alt="DriveLine Solutions" className="h-12 w-auto mb-4" />
            <p className="text-gray-300 mb-4">
              Bringing trust and transparency to the trucking industry, one driver at a time.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <Phone className="h-4 w-4 mr-2" />
                <span>(877) 724-5965</span>
              </div>
              <div className="flex items-center">
                <MapPin className="h-4 w-4 mr-2" />
                <span>3900 Crown Rd, Atlanta, GA 30304</span>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Business Hours</h3>
            <div className="space-y-1 text-sm text-gray-300">
              <div>Monday - Friday: 9:00 AM - 5:00 PM</div>
              <div>Saturday - Sunday: Closed</div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2025 DriveLine Solutions & Compliance - All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  )
}

// Main App Component
function App() {
  return (
    <Router>
      <div className="App">
        <Navigation />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/drivers" element={<DriversPage />} />
            <Route path="/carriers" element={<CarriersPage />} />
            <Route path="/compliance" element={<CompliancePage />} />
            <Route path="/recruiters" element={<RecruiterPage />} />
            <Route path="/about" element={<AboutPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  )
}

export default App
